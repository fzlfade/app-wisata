            <td><?php echo e($wisatum->id); ?></td>
            <td><?php echo e($wisatum->nama); ?></td>
            <td><?php echo e($wisatum->kota); ?></td>
            <td><?php echo e($wisatum->harga_tiket); ?></td>
            <td><img src="<?php echo e(Storage::url('public/image/' . $wisatum->image)); ?>" alt="" style="width: 150px;"></td>
<?php /**PATH /home/siswa/Desktop/app-wisata1/resources/views/wisata/show.blade.php ENDPATH**/ ?>