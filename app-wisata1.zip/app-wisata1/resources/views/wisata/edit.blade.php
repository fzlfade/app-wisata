@extends('wisata.layout')

@section('content')
<form action="{{ route('wisata.update', $wisatum->id) }}" method="POST" enctype="multipart/form-data">
@csrf
@method('PUT')


<label for="">Nama</label><br>
<input type="text" name="nama" value="{{ $wisatum->nama }}"><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" value="{{ $wisatum->kota }}"><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" value="{{ $wisatum->harga_tiket }}"><br><br>

<label for="">Image</label><br>
<input type="file" name="image"><br><br>

<input type="submit" value="Save" class="btn btn-primary">
</form>
@endsection
