@extends('wisata.layout')

@section('content')

    <a href="{{ route('wisata.create') }}" class="btn btn-primary">Add</a>

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Kota</th>
            <th>Harga Tiket</th>
            <th>Image</th>
            <th>Action</th>
        </tr>

        @foreach ($wisata as $w)
        <tr>
            <td>{{ $w->id }}</td>
            <td>{{ $w->nama }}</td>
            <td>{{ $w->kota }}</td>
            <td>{{ $w->harga_tiket }}</td>
            <td><img src="{{ Storage::url('public/image/' . $w->image) }}" alt="" style="width: 150px;"></td>
            <td><a href="{{ route('wisata.show', $w->id)   }}" class="btn btn-success">Show</a>
                <a href="{{ route('wisata.edit', $w->id)  }}" class="btn btn-warning">Edit</a>
                <form onclick="return confirm('R U Sure?')" action="{{ route('wisata.destroy', $w->id)  }}" method="POST" style="display: inline;">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger">Delete</button></form></td>

        </tr>
        @endforeach
    </table>

   {{ $wisata->links() }}
@endsection
