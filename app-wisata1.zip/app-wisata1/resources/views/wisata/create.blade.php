@extends('wisata.layout')

@section('content')
<form action="{{ route('wisata.store') }}" method="POST" enctype="multipart/form-data">
@csrf

<label for="">Nama</label><br>
<input type="text" name="nama" id=""><br><br>

<label for="">Kota</label><br>
<input type="text" name="kota" id=""><br><br>

<label for="">Harga Tiket</label><br>
<input type="number" name="harga_tiket" id=""><br><br>

<label for="">Image</label><br>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-primary">
</form>
@endsection
