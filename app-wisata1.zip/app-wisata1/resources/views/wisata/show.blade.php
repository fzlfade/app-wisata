            <td>{{ $wisatum->id }}</td>
            <td>{{ $wisatum->nama }}</td>
            <td>{{ $wisatum->kota }}</td>
            <td>{{ $wisatum->harga_tiket }}</td>
            <td><img src="{{ Storage::url('public/image/' . $wisatum->image) }}" alt="" style="width: 150px;"></td>
